## Benchmark: wikidata-pq pipeline, quick tier, 4 chunks (33,220 entities, 76 MB of source), 1 round

**after ran at 1.01× the speed of before**, -1.0% wall time

**Measured, the sample end to end** (the split, the pipeline and finalise's first run, summed; nothing modelled): CPU 4m10s → 3m52s (-7.5% ±0.0%), wall 1m09s → 1m08s (-1.0% ±0.0%). CPU by stage: the split 18.1s → 17.6s, the pipeline 9.3s → 9.6s, finalise 3m43s → 3m25s.

**Full Wikidata ETA:** 4h38m22s → 4h31m35s (-2.4% ±0.0%): the split 1h38m33s → 1h35m49s, the pipeline 44m05s → 42m36s, finalise 2h15m44s → 2h13m10s

**The ETA by stage**, modelled from each stage's measured figures (rates: the ETA's seconds a CPU-second of the sample's, after's; a CPU-second moved from one part to another changes the ETA by the difference of their rates):

| stage | CPU on the sample, measured | scaled to a release by | rate | ETA |
|---|---|---|---|---|
| split | 18.1s → 17.6s | its CPU time a byte of the slice's bz2 (79.2 MB), × the dump's 103.5 GB, over 4 cores | 327 | 1h38m33s → 1h35m49s |
| pipeline: its workers' starts | 4 → 4 workers at 1.80 → 1.88 CPU-s | a release's starts, counted (724: its 23,035 chunks, 32 a worker, 4 at once), × wall / CPU | 52 | |
| pipeline: the rest, the claims files placed among it (the split builds them) | 2.1s → 2.1s | entities (3,667×), × wall / CPU | 1,047 | |
| pipeline | 9.3s → 9.6s | (its CPU time at a release 2h29m07s → 2h28m59s, × its wall / its CPU, 0.29) | 266 | 44m05s → 42m36s |
| finalise | 3m43s → 3m25s | its time per key as measured; its CPU time per source byte (3× the rows less the first run) × the release's size, the claims' bytes (1,329×), the other tables' rows (labels 1,250×, descriptions 3,244×, aliases 1,005×, links 239×) and the rest by entities (3,667×), and the release's claims workers' starts, over 4 cores; the other tables' per-file stages × the release's files (60× the first run's), on one core | 332, 313, 811, 251, 60, 917, 60 a CPU-s per byte or file | 2h15m44s → 2h13m10s |
| all | 4m10s → 3m52s | | | 4h38m22s → 4h31m35s |

<details><summary>The ETA by runner CPU, and how it is made</summary>

20260928's 121,815,642 entities, on 20 cores. The pipeline's wall time scaled by its CPU time at the release's size over the sample's: its claims stages' by the claims' rows in each set (where the pipeline builds them), its workers' starts by a release's count, the rest by entities; finalise as it runs at the release's size (a key over 20260928's bucket threshold sorted through buckets), measured on the sample and on three times its rows: its time per key as measured, its CPU time per source byte scaled to the release's bytes over the cores (the claims key's by its bytes, the other tables' by their rows, the rest by entities), the other tables' per-file stages by a release's files. The line through the two runs is within 10% of the second's wall time. The split (split-dump, then route-release) run on a slice of a dump made of the sample's own entities: its CPU time per byte of the slice's bz2, scaled to the release's dump over the cores. It leaves out downloading the dump, and every upload, and runs the stages one after another (the release wall, modelled, overlaps them as a release does and takes in the download and the pipeline's uploads: below the overlap's table). The bucket path, measured (the sample's rows, then three times them): before: 1 and 3 source files, 1 and 4 part files, 2 and 4 buckets, 587,556 and 881,334 rows a bucket, 0% and 13% of rows spilled, 5,373 and 21,988 rows a spill flush; after: 1 and 3 source files, 1 and 4 part files, 2 and 4 buckets, 587,556 and 881,334 rows a bucket, 0% and 13% of rows spilled, 5,373 and 21,988 rows a spill flush. The claims key's workers (a worker a job: compaction, bucketing, bucket sorts, packing), measured (after): 3 in the first run and 7 on three times the rows, each 1.72 CPU-s outside its jobs (1.72 of them to its first job: the interpreter and the imports). Every worker's CPU time outside its jobs is taken out of the part per byte, which carried it scaled to the release's bytes, and the release's claims workers added back: 1,300 (the main set's 783 measured, the scholarly set's 493 modelled, and its pools' workers started with no job), modelled: 9m20s of the finalise ETA. With every start in the part per byte (bench 8.0.0's model), finalise would be 4h42m05s → 8h22m47s. Finalise's peak RSS at a release, modelled: a bucket-sort worker at 1,171,406 rows (the release's rows a bucket), from the largest bucket sorts measured, 1.98 GB at 587,707 rows and 3.08 GB at 882,834 (each worker's own peak at its exit), on the line through them (or, for runs under 20% apart in rows, in proportion to the larger's rows): 4.16 GB; 6 of them (FINALISE_WORKERS' default) at their peak at once, with the pipeline's process: 25.20 GB, summed over the processes. The claims, measured (after): built by the split, so in its CPU time and scaled with it by the dump's bytes; the pipeline only places each chunk's claims file (0.02s, scaled by entities with the rest of the pipeline); and 88% of finalise's part per byte, scaled to the release by their own bytes, not by entities (3,667×): the claims key's bytes 1,329× (94.6 GB: the main set's 44.7 GB measured, the scholarly set's modelled). (Their rows at a release: the main set's rows 1,172× (780 million, modelled), the scholarly set's 1,960× (999 million, modelled from its chunk files' 49.5 GB, measured).) Every other part but the pipeline's workers' starts and finalise's other tables (below) is scaled by entities, as before. With every part scaled by entities (bench 9.0.0's model), the ETA would be 10h19m25s → 10h12m47s: the pipeline 2h47m37s → 2h47m24s, finalise 5h53m15s → 5h49m34s. The scholarly claims at a release are the sample's scholarly claims a byte of its chunk files (25.3 MB: the tier's `s` files, route-release's one-file JSON at zstd 9, as the release's 49.5 GB are) times those 49.5 GB: 999 million rows and 49.9 GB. Bench 12.0.0 to 17.0.0 took the sample's side as its chunks' source (each part and the split's built files, another form): 785 million rows and 39.2 GB, and the ETA 4h26m03s → 4h19m22s: the pipeline 44m05s → 42m36s, finalise 2h03m25s → 2h00m57s, the claims refs 59s → 44s. The other tables' per-file stages (compaction's plan and links, the local copy's check, the sort's plans), measured (after): 2,323 group files of 2,323 keys in the first run, three times them in the second, which took 2.06 CPU-s more in those stages; of it 0.18 is their bytes' sha256 (at the claims' rate), kept in the part per byte, and the rest 0.40 ms a file. They are scaled by a release's files, not by entities: 139,380, modelled (every key in each of 30 + 30 groups, both sets'), in finalise's process a file at a time: 56s of the finalise ETA. With them scaled by entities (bench 15.0.0's model), the ETA would be 5h04m37s → 4h58m08s: finalise 2h41m59s → 2h39m43s. The other tables' per-byte stages (the decode, the sort and its check, the encode and the written file's check), measured (after), on three times the rows less the first, and scaled by each table's own rows at a release, not by entities: labels 0.80 CPU-s, 774 million rows at a release (1,250×); descriptions 1.26 CPU-s, 4,379 million rows at a release (3,244×); aliases 0.36 CPU-s, 177 million rows at a release (1,005×); links 0.84 CPU-s, 101 million rows at a release (239×). A release's rows are modelled: the main set's the 20260507 build's (2,464 million, measured) grown by 2%, the scholarly set's at the sample's rows a scholarly entity. They come to -13m09s of the finalise ETA. With them scaled by entities (bench 15.1.0's model), the ETA would be 4h51m17s → 4h44m30s: the pipeline 43m51s → 42m22s (the claims files' placing scaled by the claims' rows), finalise 2h28m53s → 2h26m19s. The pipeline's workers, measured (after): 4 (pool.process_chunks starts a worker for every 8 chunks; counted, 4), each 1.88 CPU-s outside its chunks (1.88 of them to its first: the interpreter and the imports). They are taken out of the part scaled by entities, which stood for 14,668 starts (7h39m01s of CPU), and a release's added back: 724 (12,182 and 10,853 chunks, measured, 32 a worker: CHUNKS_PER_WORKER), modelled: 22m40s of CPU. With bench 10.0.0's model (every start scaled by entities, and the split on its slice in orjson's escaping), the ETA would be 7h08m54s → 7h04m11s: the split 1h39m18s → 1h37m04s, the pipeline 2h47m37s → 2h47m24s. The runners differ in speed by up to about 1.7×; the change is paired, each commit against the other on one runner.

| runner CPU | runs | ETA, before | ETA, after | pipeline, before → after | finalise, before → after |
|---|---|---|---|---|---|
| Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz | 1 | 4h38m22s | 4h31m35s | 44m05s → 42m36s | 2h15m44s → 2h13m10s |

</details>

**The split from the gz dump** (`WIKIDATA_DUMP_FORMAT=gz`, decoded by igzip) against the split from the bz2, run after the timed run and outside its figures. The ETA is the split's CPU time per byte of the slice's dump, scaled to the newest dump on record (103.5 GB bz2, 156.6 GB gz) over the cores; decoding alone is the decoder by itself on the slice, its wall time scaled the same way (lbzip2 decodes on every core, gz decoders on one), a floor under the split's wall time that the ETA does not take in.

| | before, bz2 | before, gz | after, bz2 | after, gz |
|---|---|---|---|---|
| ETA: split | 1h38m33s | 1h25m53s | 1h35m49s | 1h25m53s |
| decoding alone, wall | 53m08s | 9m22s | 53m08s | 9m36s |
| the slice (MB) | 79.2 | 117.0 | 79.2 | 117.0 |
| CPU, split, the slice | 18.1s | 15.4s | 17.6s | 15.4s |
| CPU, decoding alone, the slice | 48.3s | 0.4s | 48.2s | 0.4s |
| wall, split, the slice | 4.64s | 4.85s | 4.65s | 4.85s |
| peak RSS, split (MB) | 3474 | 3577 | 3401 | 3664 |
| parity, split | passed | passed | passed | passed |

The split's parity: its chunks hold exactly the sample's rows; from gz, its manifests are also those of the split from bz2.

**The split and both sets' pipelines as a release runs them, the emulated link, and the release wall modelled from them:** not run on this PR (full tier on master)

**Parity:** passed

**Parity, the misfit chunk:** not run on this PR (full tier on master)

**Parity, a new claims field:** not run on this PR (full tier on master)

**The split's census of the slice's order** (after): 33,219 Q ids in 4 shards; past the shards' heads at most 1,006 below their running maximum, 0 more than 10,000 below; in the heads (below Q10,000) at most 1,968, 0 more than 10,000 below; its CPU time 0.02s in the split's workers, 0.12% of the split's

**The split by the native bz2 decoder** (after, 7 decoding threads; `WIKIDATA_BZ2_DECODER=native`, against lbzip2's, both untimed, on each runner): CPU 17.7s against 66.5s (-73.4% ±0.0%), wall 4.64s against 6.28s (-26.1% ±0.0%), peak RSS 3456 MB against 3580 MB (-3.5% ±0.0%); the decoders alone on the slice, CPU 4.5s against 48.1s (-90.6% ±0.0%), wall 0.80s against 2.62s (-69.5% ±0.0%). **Parity, every file both splits wrote byte for byte:** passed (68 files)

**Checks:** the PR tier: the timed core and parity, then the split from the gz dump and on bench 10.0.0's orjson slice (pipeline.py --split-gz): ran (changes `reshape/Cargo.lock`, `reshape/Cargo.toml`, `reshape/src/bz2_py.rs`); the stages overlapped and over the emulated link (overlap.py, link.py), and the release wall modelled from them: not run on this PR (full tier on master); the misfit chunk (misfit.py): not run on this PR (full tier on master); a new claims field (evolve.py): not run on this PR (full tier on master); the native bz2 decoder against lbzip2 (bz2native.py): ran (the PR tier; mibz2 0.3.1 (43ee26e9749a) → 0.5.6 (6931b2021dd7) in reshape/Cargo.lock; changes `reshape/Cargo.toml`, `reshape/src/bz2_py.rs`).

**before:** measured in this run

| | before (`28f8ce922`) | after (`d284b1276`) | change |
|---|---|---|---|
| measured, end to end: CPU (split + pipeline + finalise) | 4m10s | 3m52s | **-18.7s (-7.5% ±0.0%)** |
| measured, end to end: wall (split + pipeline + finalise) | 1m09s | 1m08s | **-0.66s (-1.0% ±0.0%)** |
| ETA, a release | 4h38m22s | 4h31m35s | **-6m47s (-2.4% ±0.0%)** |
| ETA: pipeline | 44m05s | 42m36s | **-1m29s (-3.4% ±0.0%)** |
| ETA: finalise | 2h15m44s | 2h13m10s | **-2m34s (-1.9% ±0.0%)** |
| ETA: split | 1h38m33s | 1h35m49s | **-2m44s (-2.8% ±0.0%)** |
| measured, end to end, with the claims refs: CPU | 4m11s | 3m52s | **-18.7s (-7.5% ±0.0%)** |
| measured, end to end, with the claims refs: wall | 1m09s | 1m08s | **-0.65s (-0.9% ±0.0%)** |
| ETA, a release, with the claims refs | 4h39m28s | 4h32m25s | **-7m03s (-2.5% ±0.0%)** |
| ETA: claims refs, modelled | 1m06s | 50s | **-16s (-24.2% ±0.0%)** |
| release wall, modelled: stages overlapped, uploads at 7 MB/s, finalise and claims refs | not run on this PR (full tier on master) | | |
| dump on disk to output on disk, modelled: stages overlapped, no transfers | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 7 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 30 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 60 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 120 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 7 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 30 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 60 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 120 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled as bench 17.1.0 did | not run on this PR (full tier on master) | | |
| claims refs | 0.08s | 0.09s | **+0.01s (+12.5% ±0.0%)** |
| CPU, claims refs | 0.5s | = |  |
| claims refs, 3× the rows | 0.14s | = |  |
| CPU, claims refs, 3× the rows | 0.9s | 0.8s | **-0.1s (-11.1% ±0.0%)** |
| peak RSS, claims refs: all processes (MB) | 461 | 460 | **-1 (-0.2% ±0.0%)** |
| peak RSS, claims refs: one worker (MB) | 21 | = |  |
| peak RSS, claims refs 3×: all processes (MB) | 570 | = |  |
| peak RSS, claims refs 3×: one worker (MB) | 21 | = |  |
| claims_labels: build, compact, sort | 2.02s | 2.04s | **+0.02s (+1.0% ±0.0%)** |
| CPU, claims_labels | 11.1s | = |  |
| claims_labels, 3× the rows | 2.44s | 2.43s | **-0.01s (-0.4% ±0.0%)** |
| CPU, claims_labels, 3× the rows | 18.5s | = |  |
| peak RSS, claims_labels: all processes (GB) | 1.529 | 1.454 | **-0.075 (-4.9% ±0.0%)** |
| peak RSS, claims_labels: one worker (MB) | 328 | 303 | **-25 (-7.6% ±0.0%)** |
| peak RSS, claims_labels 3×: all processes (GB) | 1.644 | 1.668 | **+0.024 (+1.5% ±0.0%)** |
| peak RSS, claims_labels 3×: one worker (MB) | 357 | 354 | **-3 (-0.8% ±0.0%)** |
| measured, split then each set's pipeline: wall | not run on this PR (full tier on master) | | |
| measured, split and both sets' pipelines at once: wall | not run on this PR (full tier on master) | | |
| peak RSS, split then each set's pipeline: every process | not run on this PR (full tier on master) | | |
| peak RSS, split and both sets' pipelines at once: every process | not run on this PR (full tier on master) | | |
| uploads at a release, modelled at 7 MB/s | not run on this PR (full tier on master) | | |
| measured, split and both sets' pipelines at once, pushes over a 7 MB/s link: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs through the stand-in Hub, no link: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 7 MB/s link: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 60 MB/s link: wall | not run on this PR (full tier on master) | | |
| measured, both sets' pipelines at once, pushes over a 7 MB/s link with the calls' costs: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 7 MB/s link with the calls' costs: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 60 MB/s link with the calls' costs: wall | not run on this PR (full tier on master) | | |
| measured, a misfit chunk (c0 with a reference's coordinate): CPU, split and process | not run on this PR (full tier on master) | | |
| measured, a misfit chunk: wall, split and process | not run on this PR (full tier on master) | | |
| measured, a misfit chunk: CPU, split | not run on this PR (full tier on master) | | |
| measured, a misfit chunk: CPU, process | not run on this PR (full tier on master) | | |
| measured, a new claims field (c0, a mainsnak's): CPU, the process step finding it | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, the process step once it is known (JSON) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, the split, the field known (built) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, the split, the field not known (JSON) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, a version 0 claims file written in version 1 (a merge) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, a version 0 claims file read | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, a version 0 claims file read as version 1 (finalise) | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: the process step finding it | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: a version 0 claims file written in version 1 | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: a version 0 claims file read | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: a version 0 claims file read as version 1 | not run on this PR (full tier on master) | | |
| disk, a new claims field: a version 0 claims file written in version 1 (MB, until merged) | not run on this PR (full tier on master) | | |
| wall, with finalise | 1m04s | = |  |
| wall | 2.74s | = |  |
| finalise: compact | 0.98s | 0.97s | **-0.01s (-1.0% ±0.0%)** |
| finalise: sort | 1m00s | = |  |
| finalise, 3× the rows | 1m08s | 1m09s | **+0.12s (+0.2% ±0.0%)** |
| split: split | 3.84s | = |  |
| split: route | 0.80s | 0.81s | **+0.01s (+1.2% ±0.0%)** |
| CPU, split | 18.1s | 17.6s | **-0.5s (-2.8% ±0.0%)** |
| peak RSS, split (GB) | 3.474 | 3.401 | **-0.073 (-2.1% ±0.0%)** |
| ETA: split from gz | 1h25m53s | = |  |
| CPU, split from gz | 15.4s | = |  |
| throughput (entities/s) | 12,124 | = |  |
| CPU, all processes | 9.3s | 9.6s | **+0.3s (+3.2% ±0.0%)** |
| CPU, process | 0.1s | = |  |
| CPU, partition | 0.1s | = |  |
| CPU, group merges | 1.5s | = |  |
| CPU, finalise | 3m43s | 3m25s | **-18.5s (-8.3% ±0.0%)** |
| peak RSS, all processes (MB) | 950 | 768 | **-182 (-19.2% ±0.0%)** |
| peak RSS, one worker (MB) | 182 | 181 | **-1 (-0.5% ±0.0%)** |
| peak RSS, finalise: all processes (GB) | 4.232 | 4.174 | **-0.058 (-1.4% ±0.0%)** |
| peak RSS, finalise: one worker (GB) | 2.015 | 1.982 | **-0.033 (-1.6% ±0.0%)** |
| peak RSS, finalise 3×: all processes (GB) | 10.741 | 10.659 | **-0.082 (-0.8% ±0.0%)** |
| peak RSS, finalise 3×: one worker (GB) | 3.123 | 3.083 | **-0.040 (-1.3% ±0.0%)** |
| peak RSS, finalise at a release, modelled: a bucket sort (GB) | 4.200 | 4.160 | **-0.040 (-1.0% ±0.0%)** |
| peak RSS, finalise at a release, modelled: all processes (GB) | 25.446 | 25.204 | **-0.242 (-1.0% ±0.0%)** |
| CPU, a claims worker outside its jobs | 1.75s | 1.72s | **-0.02s (-1.4% ±0.0%)** |
| CPU, the pipeline's claims stages | 0.0s | = |  |
| CPU, a pipeline worker outside its chunks | 1.80s | 1.88s | **+0.08s (+4.4% ±0.0%)** |
| disk used, peak rise (MB) | 580 | = |  |

**Where the CPU goes**, by stage: each stage's own CPU time in its process (its worker's native threads included, the stages it calls apart), the mean over the rounds, and its share of the span's.

| stage | before | after | change |
|---|---|---|---|
| *the split and routing of the dump slice*: 4.6s → 4.4s | | | |
| `partitioning.core.write_table` | 5.9s (130%) | 6.2s (141%) | **+5.4% ±0.0%** |
| `dump.write_chunk` | 3.2s (71%) | 3.1s (71%) | **-3.1% ±0.0%** |
| `partitioning.claims.statements` | 0.2s (5%) | 0.3s (6%) | **+15.7% ±0.0%** |
| `claims_refs.write_refs` | 0.1s (2%) | 0.1s (2%) | **+4.4% ±0.0%** |
| *the pipeline, every chunk*: 1.2s → 1.2s | | | |
| `push.core.merge_group` | 1.1s (94%) | 1.1s (94%) | **-0.5% ±0.0%** |
| `process.check_ids` | 0.0s (3%) | 0.0s (3%) | **+2.6% ±0.0%** |
| `partitioning.core.write_sidecar` | 0.0s (1%) | 0.0s (1%) | **+0.0% ±0.0%** |
| `other` | 0.0s (2%) | 0.0s (2%) |  |
| *finalise, per byte (the run on three times the rows less the first; what the ETA scales)*: 43.9s → 44.0s | | | |
| `compact._write_file_parallel` | 17.6s (40%) | 17.6s (40%) | **+0.1% ±0.0%** |
| `sort_by_id._read_bucket` | 7.8s (18%) | 7.7s (17%) | **-2.2% ±0.0%** |
| `sort_by_id._check_written` | 4.5s (10%) | 4.5s (10%) | **+0.9% ±0.0%** |
| `sort_by_id._bucket_source` | 3.5s (8%) | 3.4s (8%) | **-2.8% ±0.0%** |
| `sort_by_id._sorted` | 3.4s (8%) | 3.4s (8%) | **-0.8% ±0.0%** |
| `sort_by_id._read_streams` | 2.2s (5%) | 2.4s (6%) | **+13.3% ±0.0%** |
| `compact.rewrite_table` | 1.5s (3%) | 1.6s (4%) | **+3.3% ±0.0%** |
| `sort_by_id._read_key` | 1.0s (2%) | 1.0s (2%) | **-2.0% ±0.0%** |
| `sort_by_id._ipc_stream` | 0.7s (2%) | 0.8s (2%) | **+14.4% ±0.0%** |
| `sort_by_id.check_compacted_copy` | 0.7s (1%) | 0.7s (1%) | **+0.3% ±0.0%** |
| `other` | 1.0s (2%) | 1.0s (2%) |  |

**Where finalise's wall time goes**, beside its CPU (timeline.py): each stage's wall time, the cores busy over it (the machine's CPU time over its wall, of 20) and the core-seconds left idle (20 × its wall less that CPU time), the mean over the rounds.

| stage | before | after |
|---|---|---|
| *finalise, 3× the rows* | 1m08s, 3.8 busy, 1107 idle | 1m09s, 4.0 busy, 1099 idle |
| `write_table claims: claims/all bucketing` | 2.23s, 5.2 busy, 33 idle | 2.20s, 5.0 busy, 33 idle |
| `write_table claims: claims/all bucket sorts` | 6.64s, 7.8 busy, 81 idle | 6.69s, 7.7 busy, 82 idle |
| `write_table labels` | 6.76s, 3.5 busy, 111 idle | 6.64s, 3.5 busy, 110 idle |
| `write_table descriptions` | 38.36s, 3.6 busy, 629 idle | 38.44s, 3.9 busy, 620 idle |
| `write_table aliases` | 1.68s, 3.0 busy, 28 idle | 1.69s, 2.8 busy, 29 idle |
| `write_table links` | 5.58s, 3.1 busy, 94 idle | 5.62s, 3.3 busy, 94 idle |
| *per byte: 3× the rows less the first run* | +6.98s, CPU +37s, idle +103s | +7.77s, CPU +66s, idle +89s |
| `write_table claims: claims/all bucket sorts` | +2.21s, CPU +36s, idle +8s | +2.38s, CPU +37s, idle +10s |
| `compact_table entities` | +1.06s, CPU +3s, idle +18s | +1.08s, CPU +3s, idle +19s |
| `write_table claims: claims/all bucketing` | +0.75s, CPU +8s, idle +7s | +0.75s, CPU +8s, idle +7s |
| `write_table descriptions` | +0.15s, CPU -16s, idle +19s | +0.72s, CPU +13s, idle +1s |
| `compact_table links` | +0.49s, CPU +0s, idle +10s | +0.52s, CPU +0s, idle +10s |
| `write_table links` | +0.31s, CPU +2s, idle +4s | +0.34s, CPU +2s, idle +5s |
| `compact_table labels` | +0.32s, CPU +0s, idle +6s | +0.33s, CPU +0s, idle +6s |
| `compact_table aliases` | +0.26s, CPU +0s, idle +5s | +0.27s, CPU +0s, idle +5s |
| `write_table labels` | +0.37s, CPU +2s, idle +5s | +0.27s, CPU +1s, idle +4s |
| `compact_table descriptions` | +0.26s, CPU +0s, idle +5s | +0.26s, CPU +0s, idle +5s |
| `compact_table claims` | +0.23s, CPU +0s, idle +4s | +0.23s, CPU +0s, idle +4s |
| `write_table aliases` | +0.11s, CPU +0s, idle +2s | +0.14s, CPU +0s, idle +3s |
| `write_table entities: entities/all bucket sorts` | +0.02s, CPU +1s, idle +0s | +0.08s, CPU +0s, idle +1s |
| `check_compacted_copy links` | +0.08s, CPU +0s, idle +1s | +0.08s, CPU +0s, idle +1s |
| `check_compacted_copy labels` | +0.07s, CPU +0s, idle +1s | +0.07s, CPU -0s, idle +1s |
| `write_table entities: entities/all bucketing` | 0.00s, CPU -1s, idle +1s | -0.02s, CPU -0s, idle -0s |

<details><summary>Each stage's jobs, on three times the rows (after)</summary>

| stage | start → end | jobs (workers) | running at once: mean, peak | longest | last alone | cores waiting on I/O | disk busy |
|---|---|---|---|---|---|---|---|
| `compact_table claims` | 0.0s → 0.3s | – | –, – | – | – | 0.00 | 0% |
| `compact_table labels` | 0.3s → 0.9s | – | –, – | – | – | 0.00 | 0% |
| `compact_table descriptions` | 0.9s → 1.3s | – | –, – | – | – | 0.00 | 0% |
| `compact_table aliases` | 1.3s → 1.8s | – | –, – | – | – | 0.00 | 0% |
| `compact_table links` | 1.8s → 2.6s | – | –, – | – | – | 0.00 | 0% |
| `compact_table entities` | 2.6s → 3.7s | 1 (1) | 1.0, 1 | 0.0s | 0.0s | 0.00 | 0% |
| `check_compacted_copy claims` | 3.7s → 3.9s | – | –, – | – | – | 0.02 | 0% |
| `write_table claims: claims/all bucketing` | 3.9s → 6.1s | 3 (3) | 2.9, 3 | 0.8s | 0.0s | 0.00 | 0% |
| `write_table claims: claims/all bucket sorts` | 6.1s → 12.8s | 4 (4) | 3.7, 4 | 5.2s | 0.4s | 0.00 | 0% |
| `check_compacted_copy labels` | 12.8s → 12.9s | – | –, – | – | – | 0.00 | 0% |
| `write_table labels` | 12.9s → 19.5s | 564 (11) | 0.3, 4 | 0.1s | 0.0s | 0.00 | 0% |
| `write_table descriptions` | 19.6s → 58.1s | 442 (66) | 0.1, 4 | 0.1s | 0.0s | 0.00 | 0% |
| `write_table aliases` | 58.2s → 59.9s | 489 (6) | 2.0, 4 | 0.0s | 0.0s | 0.00 | 0% |
| `check_compacted_copy links` | 60.0s → 60.1s | – | –, – | – | – | 0.00 | 0% |
| `write_table links` | 60.1s → 65.7s | 827 (11) | 0.5, 4 | 0.0s | 0.0s | 0.00 | 0% |
| `write_table entities: entities/all bucketing` | 65.8s → 67.1s | 1 (1) | 1.0, 1 | 0.0s | 0.0s | 0.00 | 0% |
| `write_table entities: entities/all bucket sorts` | 67.1s → 68.4s | 1 (1) | 1.0, 1 | 0.1s | 0.1s | 0.01 | 0% |

</details>

One round.

**Runners:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz; 20 cores, 125.7 GB, Python 3.13.7  
**Packages, before:** polars 2.0.0, polars-genson 1.6.0, pq-glue 0.3.0, pyarrow 25.0.1, orjson 3.12.0  
**Packages, after:** =  
**Data:** the 11 chunk files, SHA256SUMS hashing to `ae83fc382e62853f`  
**Harness:** bench 17.23.0


<details><summary>Section durations</summary>

Each section's wall, a mean over the 1 jobs (each a round's forward or reverse runner); a job's is both arms' together, the slowest job's in brackets. The PR tier runs on every pull request; the full tier's sections on master, nightly, and on a pull request they are relevant to (tiers.py).

| section | tier | before | after | a job |
|---|---|---|---|---|
| setup: checkouts, data, decoders, environments | PR | | | – |
| the timed core: split, pipeline, finalise, finalise 3×, claims_labels, claims refs | PR | 2m41s | 2m41s | 5m22s (5m22s) |
| parity: both arms' outputs fingerprinted and compared | PR | | | 37.0s (37.0s) |
| the split from the gz dump and on bench 10.0.0's orjson slice (pipeline.py --split-gz) | full | 39.8s | 39.8s | 1m20s (1m20s) |
| the stages overlapped and over the emulated link (overlap.py, link.py), and the release wall modelled from them | full | not run on this PR (full tier on master) | | |
| the misfit chunk (misfit.py) | full | not run on this PR (full tier on master) | | |
| a new claims field (evolve.py) | full | not run on this PR (full tier on master) | | |
| the native bz2 decoder against lbzip2 (bz2native.py) | PR | 16.4s | 16.2s | 32.6s (32.6s) |
| **the PR tier: a job's start to its figures** | | | | **–** |
| a job's start to its last section | | | | – |

</details>
<details><summary>Parity, after against before</summary>

```json
{
 "keys": 2324,
 "keys_per_table": {
  "aliases": 489,
  "claims": 1,
  "descriptions": 442,
  "entities": 1,
  "labels": 564,
  "links": 827
 },
 "keys_differing": [],
 "published_keys": 2842,
 "published_differing": [],
 "keys_reordered": [],
 "quarantine_files": 0,
 "quarantine_same": true,
 "sidecars": 35,
 "sidecars_same_set": true,
 "sidecar_columns_differing": {},
 "ok": true
}
```
</details>
