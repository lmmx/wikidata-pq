**The mibz2 version ladder**, attempt `20261115T154314Z`: 8 steps, bench-i9 each

| Step | mibz2 | Before | After | Outcome | Submitted |
|---|---|---|---|---|---|
| pilot | 0.3.1 → 0.3.3 | `cd305f33` | `a3047bfe` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/pull/227#issuecomment-6897050906 |
| 0.2.1 | 0.1.4 → 0.2.1 | `a1f2a958` | `d09edd91` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897052387 |
| 0.2.2 | 0.2.1 → 0.2.2 | `d09edd91` | `f8e1c430` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897053963 |
| 0.2.5 | 0.2.2 → 0.2.5 | `f8e1c430` | `520bb378` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897055423 |
| 0.2.8 | 0.2.5 → 0.2.8 | `520bb378` | `6155aaa6` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897056673 |
| 0.2.9 | 0.2.8 → 0.2.9 | `6155aaa6` | `45697167` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897058041 |
| 0.3.0 | 0.2.9 → 0.3.0 | `45697167` | `d1536bb6` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897059590 |
| 0.3.1 | 0.3.0 → 0.3.1 | `d1536bb6` | `cd305f33` | INCOMPLETE: decoders | yes: https://github.com/lmmx/wikidata-pq/issues/97#issuecomment-6897060968 |
