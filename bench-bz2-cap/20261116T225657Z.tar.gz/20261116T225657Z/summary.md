# The native bz2 decoder's threads through the split (ffe54484f4)

- **Machine:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz; 20 logical CPUs on 10 physical cores (L3 20480K); 125.7 GB. `auto` is 4 decoder threads here.
- **Held constant (each run's log):** [18] parse workers, [18] writer threads; every split from nothing.
- **Workload:** bench-full's run (`--release 20261019 --windows 24 --window-mb 25`); 8 rounds, each arm once a round, the order rotated and reversed (`arm_order`).
- **Paired:** each round's ratio to `auto` in the same round, the mean and its 95% interval; *lower* or *higher* only when the interval excludes no change.

## Release-shaped (bench-full run)

`run.py run --release 20261019 --windows 24 --window-mb 25`

| threads | wall (s), median | CPU-s | peak RSS (MB) | split wall (s) | split CPU-s | wall vs auto | CPU vs auto | split wall vs auto | split CPU vs auto | runs |
|---|---|---|---|---|---|---|---|---|---|---|
| auto (4) | 89 | 575 | 20793 | 18 | 207 | control | control | control | control | 8 |
| 6 (6) | 88 | 611 | 20684 | 19 | 239 | -0.1% ±0.8% (within noise) | +6.3% ±0.2% (higher) | +4.4% ±0.5% (higher) | +15.7% ±0.4% (higher) | 8 |
| 8 (8) | 88 | 619 | 20786 | 19 | 248 | -0.3% ±0.8% (within noise) | +7.7% ±0.4% (higher) | +2.7% ±0.6% (higher) | +20.0% ±0.6% (higher) | 8 |
| 9 (9) | 88 | 626 | 20719 | 19 | 255 | -0.1% ±0.9% (within noise) | +8.8% ±0.3% (higher) | +3.6% ±0.6% (higher) | +23.0% ±0.4% (higher) | 8 |
| 10 (10) | 88 | 632 | 20787 | 19 | 260 | +0.0% ±0.7% (within noise) | +9.7% ±0.3% (higher) | +4.8% ±0.7% (higher) | +25.5% ±0.7% (higher) | 8 |

- **6 against auto, paired:** peak RSS -0.2% ±1.4% (within noise); +36.1 CPU-s and +0.11 s of wall saved a round, mean: 343.7 CPU-s per wall-s saved
- **8 against auto, paired:** peak RSS +0.5% ±0.9% (within noise); +44.1 CPU-s and +0.28 s of wall saved a round, mean: 158.1 CPU-s per wall-s saved
- **9 against auto, paired:** peak RSS +0.1% ±1.2% (within noise); +50.6 CPU-s and +0.05 s of wall saved a round, mean: 964.5 CPU-s per wall-s saved
- **10 against auto, paired:** peak RSS +0.3% ±1.2% (within noise); +55.5 CPU-s and -0.01 s of wall saved a round, mean: no wall saved
- **Parity:** 40 of 40 runs ok, their published files' digest the first run's.

## The plan each arm gets (derived, not logged)

mibz2 0.5.2's Plan::for_threads, derived for 10 physical cores and a 20 MiB L3 (not logged by the split)
- `auto` (4 threads): Workers(4)
- `6` (6 threads): Workers(6)
- `8` (8 threads): Workers(8) (lazy letters)
- `9` (9 threads): Workers(9) (lazy letters)
- `10` (10 threads): Workers(10) (lazy letters)
