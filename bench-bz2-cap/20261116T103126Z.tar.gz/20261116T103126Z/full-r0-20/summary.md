# Compute benchmark: 20261116-103939-windows24x25m-local-overlap

- **Result:** ok; both sets finalised: {'main': True, 'scholar': True}
- **Dump:** release 20261019, windows24x25m: 0.60 GB of bz2, 11.19 GB of JSON; the whole dump's md5 cfec3f8ab5fd8f6f0b70f58c590a02da, sha1 a05b8b809ab80576da6d838c67138ddf401055e6
- **Source:** local (no network on the timed path); orchestration: overlap; cards: False
- **Machine:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz, 20 CPUs, 134.96 GB RAM, ecryptfs on /home/louis/.Private (model unknown), Linux Mint 22, kernel 6.8.0-57-generic
- **Code:** 9a361116 (9a361116d58db517a5de65aa3137ba6946c2c40d), wikidata 0.1.0, wikidata-reshape 0.1.0, polars 2.0.0, pyarrow 25.0.1, pq-glue 0.3.0, polars-genson 1.6.0, orjson 3.12.0, numpy 2.5.3, huggingface-hub 1.32.0, hf-xet 1.6.0
- **Decoder:** native (lbzip2's command: ['/usr/bin/lbzip2', '-dc']; an in-process decoder's threads: 20); WIKIDATA_BZ2_DECODER=native, WIKIDATA_BZ2_THREADS=20, WIKIDATA_SPLIT_WRITER_THREADS=0

## Measured

- **Wall, end to end:** 89 s; **CPU:** 636 s (7.11 cores on average)
- **Time to the first processed chunk** (the split's first chunk written): 3.0 s; each set's first part ready for its run: {'main': 3.0, 'scholar': 3.0} s (±1 s, the monitor's interval)
- **Peak RSS, every process at once:** 21024 MB (the largest process 12709 MB); the machine's memory in use at its peak 28716 MB (least available 106245 MB, other work included)
- **Disk:** peak 1.23 GB taken (free space's fall), work tree peak 1.75 GB; the device read – GB and wrote – GB; the stages' own I/O read 0.00 GB and wrote 2.97 GB
- **Network:** received 0.00 GB, sent 0.00 GB (the machine's, every process)
- **Other work on the machine:** 2.1 CPU s besides the run's own (0.02 cores on average; mean load 8.47). Near 0, the run had the machine to itself

| stage | start s | wall s | CPU s | cores | other CPU s | peak RSS MB (tree) | read GB | written GB | machine: user / sys / iowait / idle | bound |
|---|--:|--:|--:|--:|--:|--:|--:|--:|---|---|
| split | 0 | 19.7 | 266.9 | 13.55 | 40.6 | 8774 | 0.00 | 1.01 | 72% / 5% / 0% / 23% | CPU on 13.5 of 20 cores (serial parts, or waiting on another stage) |
| run_scholar | 0 | 27.7 | 24.7 | 0.89 | 300.8 | 645 | 0.00 | 0.36 | 54% / 4% / 0% / 42% | CPU on 0.9 of 20 cores (serial parts, or waiting on another stage) |
| run_main | 0 | 26.5 | 30.8 | 1.16 | 293.0 | 658 | 0.00 | 0.50 | 56% / 4% / 0% / 40% | CPU on 1.2 of 20 cores (serial parts, or waiting on another stage) |
| finalise | 26 | 54.1 | 297.3 | 5.50 | 4.0 | 21024 | 0.00 | 1.10 | 24% / 3% / 0% / 72% | CPU on 5.5 of 20 cores (serial parts, or waiting on another stage) |
| tail_run_scholar | 81 | 1.2 | 2.7 | 2.19 | 1.9 | 88 | 0.00 | 0.00 | 10% / 1% / 0% / 88% | CPU on 2.2 of 20 cores (serial parts, or waiting on another stage) |
| tail_run_main | 82 | 1.2 | 2.7 | 2.20 | 2.3 | 69 | 0.00 | 0.00 | 12% / 1% / 0% / 88% | CPU on 2.2 of 20 cores (serial parts, or waiting on another stage) |
| tail_finalise | 83 | 6.4 | 10.5 | 1.65 | 0.3 | 286 | 0.00 | 0.00 | 8% / 0% / 0% / 92% | CPU on 1.7 of 20 cores (serial parts, or waiting on another stage) |

(Overlapped stages share the machine: their machine-wide split is the window's, not theirs alone.)

| finalise run | start s | wall s | CPU s | largest process MB |
|---|--:|--:|--:|--:|
| finalise_run1_main | 28 | 24.6 | 96.6 | 12189 |
| finalise_run2_scholar | 53 | 23.6 | 175.5 | 3434 |
| finalise_run3_main | 77 | 3.9 | 22.6 | 450 |
| tail_finalise_run1_main | 84 | 1.2 | 2.7 | 172 |
| tail_finalise_run2_scholar | 86 | 1.2 | 2.7 | 170 |
| tail_finalise_run3_main | 88 | 1.2 | 2.7 | 172 |

**claims_labels** (its build, compaction and sort, within finalise's runs): main 2.2 s wall, 18.6 s CPU; scholar 0.9 s wall, 12.8 s CPU

<details><summary>finalise's steps and the group closes (wall, CPU incl. workers)</summary>

| step | calls | wall s | CPU s |
|---|--:|--:|--:|
| main/build_claims_labels | 3 | 2.1 | 18.5 |
| main/close_group | 1 | 5.5 | 7.3 |
| main/collect_refs_stage | 4 | 0.2 | 1.2 |
| main/compact_table/aliases | 4 | 0.3 | 0.5 |
| main/compact_table/claims | 4 | 0.5 | 0.5 |
| main/compact_table/claims_labels | 3 | 0.0 | 0.0 |
| main/compact_table/descriptions | 4 | 0.3 | 0.4 |
| main/compact_table/entities | 4 | 0.1 | 0.1 |
| main/compact_table/labels | 4 | 0.4 | 0.7 |
| main/compact_table/links | 4 | 0.5 | 0.6 |
| main/sort_table/aliases | 4 | 0.3 | 1.8 |
| main/sort_table/claims | 4 | 16.1 | 62.4 |
| main/sort_table/claims_labels | 3 | 0.0 | 0.1 |
| main/sort_table/descriptions | 4 | 1.1 | 7.4 |
| main/sort_table/entities | 4 | 0.4 | 0.7 |
| main/sort_table/labels | 4 | 2.1 | 14.1 |
| main/sort_table/links | 4 | 0.3 | 1.8 |
| scholar/build_claims_labels | 2 | 0.9 | 12.7 |
| scholar/close_group | 1 | 7.2 | 3.2 |
| scholar/collect_refs_stage | 2 | 0.4 | 3.4 |
| scholar/compact_table/aliases | 2 | 0.1 | 0.1 |
| scholar/compact_table/claims | 2 | 0.4 | 0.5 |
| scholar/compact_table/claims_labels | 2 | 0.0 | 0.0 |
| scholar/compact_table/descriptions | 2 | 0.2 | 0.2 |
| scholar/compact_table/entities | 2 | 0.0 | 0.0 |
| scholar/compact_table/labels | 2 | 0.1 | 0.2 |
| scholar/compact_table/links | 2 | 0.0 | 0.1 |
| scholar/sort_table/aliases | 2 | 0.0 | 0.2 |
| scholar/sort_table/claims | 2 | 16.8 | 134.9 |
| scholar/sort_table/claims_labels | 2 | 0.0 | 0.1 |
| scholar/sort_table/descriptions | 2 | 1.1 | 6.8 |
| scholar/sort_table/entities | 2 | 0.2 | 0.3 |
| scholar/sort_table/labels | 2 | 1.7 | 12.0 |
| scholar/sort_table/links | 2 | 0.0 | 0.1 |

</details>

## Transfers a release would make (logged by the stand-in Hub, not timed)

| way | set/kind | calls | files | GB |
|---|---|--:|--:|--:|
| upload | main/commit | 14 | 2453 | 0.42 |
| upload | main/file | 6 | 6 | 0.00 |
| upload | main/group | 6 | 1982 | 0.45 |
| upload | scholar/commit | 7 | 542 | 0.33 |
| upload | scholar/file | 6 | 6 | 0.00 |
| upload | scholar/group | 6 | 305 | 0.34 |
| download | main/snapshot | 6 | 1982 | 0.45 |
| download | scholar/snapshot | 6 | 305 | 0.34 |

Uploads in all: 1.53 GB (at 7 MB/s, the one rate on record: 0.1 h; at 60 MB/s: 0.0 h; modelled, not measured).
The stand-in's own cost on the timed path (the Hub-side sha256 it computes): 2.5 s CPU over 1.53 GB.
Linked files changed after placing: 0 of 2995 checked (0 copied, not linked). Published digest: 3ad0c4aad5deeb7c6450d506038d34a1daace866f4c54d4e68ce65b4a75e3d48

## Per GB of bz2, against the CI bench's model

0.5988 GB of bz2; JSON 18.68x its bz2 bytes (the CI bench's slice 13.69x, #194's 12 windows of the real dump 17.46x).

| stage | CPU s / GB | CPU / 4 cores, s / GB (measured) | model s / GB (CI bench) | measured / model | wall s / GB | measured / model, a JSON byte |
|---|--:|--:|--:|--:|--:|--:|
| split | 445.8 | 111.4 | 116.0 | 0.96 | 32.9 | 0.7 |
| pipeline | 92.7 | 23.2 | 55.1 | 0.42 | – | 0.31 |
| finalise | 514.1 | 128.5 | 77.1 | 1.67 | – | 1.22 |

The model: bench 17.12.0's release model at master 8f7720b (6 runs, AMD EPYC 7763, 4 cores): a stage's sample CPU time scaled to the release and spread over 4 cores. Its figures are modelled; this run's are measured. A JSON byte's: the model's CPU over its slice's JSON (13.69x its bz2 bytes).

**Modelled** (this run's rates, linear in bz2 bytes, to the release's 103.5 GB): wall 4.3 h, CPU 30.5 h, peak disk ~213 GB (2.05x the bz2). this scaled run's figures times the release's bz2 bytes over its own: linear in bytes, which a sample of the dump's mix only approximates; modelled, not measured.
