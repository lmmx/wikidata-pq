## Benchmark: wikidata-pq pipeline, quick tier, 4 chunks (33,220 entities, 76 MB of source), 1 round

**after ran at 1.01× the speed of before**, -1.2% wall time

**Measured, the sample end to end** (the split, the pipeline and finalise's first run, summed; nothing modelled): CPU 4m04s → 3m54s (-4.3% ±0.0%), wall 1m09s → 1m08s (-1.1% ±0.0%). CPU by stage: the split 18.1s → 17.9s, the pipeline 9.1s → 9.6s, finalise 3m37s → 3m26s.

**Full Wikidata ETA:** 4h37m42s → 4h35m24s (-0.8% ±0.0%): the split 1h38m33s → 1h37m27s, the pipeline 45m21s → 44m10s, finalise 2h13m48s → 2h13m48s

**The ETA by stage**, modelled from each stage's measured figures (rates: the ETA's seconds a CPU-second of the sample's, after's; a CPU-second moved from one part to another changes the ETA by the difference of their rates):

| stage | CPU on the sample, measured | scaled to a release by | rate | ETA |
|---|---|---|---|---|
| split | 18.1s → 17.9s | its CPU time a byte of the slice's bz2 (79.2 MB), × the dump's 103.5 GB, over 4 cores | 327 | 1h38m33s → 1h37m27s |
| pipeline: its workers' starts | 4 → 4 workers at 1.75 → 1.87 CPU-s | a release's starts, counted (724: its 23,035 chunks, 32 a worker, 4 at once), × wall / CPU | 52 | |
| pipeline: the rest, the claims files placed among it (the split builds them) | 2.1s → 2.1s | entities (3,667×), × wall / CPU | 1,058 | |
| pipeline | 9.1s → 9.6s | (its CPU time at a release 2h31m04s → 2h33m58s, × its wall / its CPU, 0.29) | 276 | 45m21s → 44m10s |
| finalise | 3m37s → 3m26s | its time per key as measured; its CPU time per source byte (3× the rows less the first run) × the release's size, the claims' bytes (1,329×), the other tables' rows (labels 1,250×, descriptions 3,244×, aliases 1,005×, links 239×) and the rest by entities (3,667×), and the release's claims workers' starts, over 4 cores; the other tables' per-file stages × the release's files (60× the first run's), on one core | 332, 313, 811, 251, 60, 917, 60 a CPU-s per byte or file | 2h13m48s → 2h13m48s |
| all | 4m04s → 3m54s | | | 4h37m42s → 4h35m24s |

<details><summary>The ETA by runner CPU, and how it is made</summary>

20260928's 121,815,642 entities, on 20 cores. The pipeline's wall time scaled by its CPU time at the release's size over the sample's: its claims stages' by the claims' rows in each set (where the pipeline builds them), its workers' starts by a release's count, the rest by entities; finalise as it runs at the release's size (a key over 20260928's bucket threshold sorted through buckets), measured on the sample and on three times its rows: its time per key as measured, its CPU time per source byte scaled to the release's bytes over the cores (the claims key's by its bytes, the other tables' by their rows, the rest by entities), the other tables' per-file stages by a release's files. The line through the two runs is within 9% of the second's wall time. The split (split-dump, then route-release) run on a slice of a dump made of the sample's own entities: its CPU time per byte of the slice's bz2, scaled to the release's dump over the cores. It leaves out downloading the dump, and every upload, and runs the stages one after another (the release wall, modelled, overlaps them as a release does and takes in the download and the pipeline's uploads: below the overlap's table). The bucket path, measured (the sample's rows, then three times them): before: 1 and 3 source files, 1 and 4 part files, 2 and 4 buckets, 587,556 and 881,334 rows a bucket, 0% and 13% of rows spilled, 5,373 and 21,988 rows a spill flush; after: 1 and 3 source files, 1 and 4 part files, 2 and 4 buckets, 587,556 and 881,334 rows a bucket, 0% and 13% of rows spilled, 5,373 and 21,988 rows a spill flush. The claims key's workers (a worker a job: compaction, bucketing, bucket sorts, packing), measured (after): 3 in the first run and 7 on three times the rows, each 1.73 CPU-s outside its jobs (1.73 of them to its first job: the interpreter and the imports). Every worker's CPU time outside its jobs is taken out of the part per byte, which carried it scaled to the release's bytes, and the release's claims workers added back: 1,300 (the main set's 783 measured, the scholarly set's 493 modelled, and its pools' workers started with no job), modelled: 9m21s of the finalise ETA. With every start in the part per byte (bench 8.0.0's model), finalise would be 7h27m03s → 6h40m27s. Finalise's peak RSS at a release, modelled: a bucket-sort worker at 1,171,406 rows (the release's rows a bucket), from the largest bucket sorts measured, 2.04 GB at 587,707 rows and 3.12 GB at 882,834 (each worker's own peak at its exit), on the line through them (or, for runs under 20% apart in rows, in proportion to the larger's rows): 4.17 GB; 6 of them (FINALISE_WORKERS' default) at their peak at once, with the pipeline's process: 25.25 GB, summed over the processes. The claims, measured (after): built by the split, so in its CPU time and scaled with it by the dump's bytes; the pipeline only places each chunk's claims file (0.02s, scaled by entities with the rest of the pipeline); and 87% of finalise's part per byte, scaled to the release by their own bytes, not by entities (3,667×): the claims key's bytes 1,329× (94.6 GB: the main set's 44.7 GB measured, the scholarly set's modelled). (Their rows at a release: the main set's rows 1,172× (780 million, modelled), the scholarly set's 1,960× (999 million, modelled from its chunk files' 49.5 GB, measured).) Every other part but the pipeline's workers' starts and finalise's other tables (below) is scaled by entities, as before. With every part scaled by entities (bench 9.0.0's model), the ETA would be 10h17m17s → 10h16m26s: the pipeline 2h47m38s → 2h49m07s, finalise 5h51m06s → 5h49m53s. The scholarly claims at a release are the sample's scholarly claims a byte of its chunk files (25.3 MB: the tier's `s` files, route-release's one-file JSON at zstd 9, as the release's 49.5 GB are) times those 49.5 GB: 999 million rows and 49.9 GB. Bench 12.0.0 to 17.0.0 took the sample's side as its chunks' source (each part and the split's built files, another form): 785 million rows and 39.2 GB, and the ETA 4h25m30s → 4h23m14s: the pipeline 45m21s → 44m10s, finalise 2h01m36s → 2h01m38s, the claims refs 44s → 44s. The other tables' per-file stages (compaction's plan and links, the local copy's check, the sort's plans), measured (after): 2,323 group files of 2,323 keys in the first run, three times them in the second, which took 2.08 CPU-s more in those stages; of it 0.18 is their bytes' sha256 (at the claims' rate), kept in the part per byte, and the rest 0.41 ms a file. They are scaled by a release's files, not by entities: 139,380, modelled (every key in each of 30 + 30 groups, both sets'), in finalise's process a file at a time: 57s of the finalise ETA. With them scaled by entities (bench 15.0.0's model), the ETA would be 5h05m34s → 5h02m19s: finalise 2h41m40s → 2h40m43s. The other tables' per-byte stages (the decode, the sort and its check, the encode and the written file's check), measured (after), on three times the rows less the first, and scaled by each table's own rows at a release, not by entities: labels 0.84 CPU-s, 774 million rows at a release (1,250×); descriptions 1.33 CPU-s, 4,379 million rows at a release (3,244×); aliases 0.37 CPU-s, 177 million rows at a release (1,005×); links 0.83 CPU-s, 101 million rows at a release (239×). A release's rows are modelled: the main set's the 20260507 build's (2,464 million, measured) grown by 2%, the scholarly set's at the sample's rows a scholarly entity. They come to -13m22s of the finalise ETA. With them scaled by entities (bench 15.1.0's model), the ETA would be 4h50m55s → 4h48m32s: the pipeline 45m06s → 43m56s (the claims files' placing scaled by the claims' rows), finalise 2h27m16s → 2h27m10s. The pipeline's workers, measured (after): 4 (pool.process_chunks starts a worker for every 8 chunks; counted, 4), each 1.87 CPU-s outside its chunks (1.87 of them to its first: the interpreter and the imports). They are taken out of the part scaled by entities, which stood for 14,668 starts (7h38m05s of CPU), and a release's added back: 724 (12,182 and 10,853 chunks, measured, 32 a worker: CHUNKS_PER_WORKER), modelled: 22m37s of CPU. With bench 10.0.0's model (every start scaled by entities, and the split on its slice in orjson's escaping), the ETA would be 7h09m09s → 7h08m00s: the split 1h39m51s → 1h38m11s, the pipeline 2h47m38s → 2h49m07s. The runners differ in speed by up to about 1.7×; the change is paired, each commit against the other on one runner.

| runner CPU | runs | ETA, before | ETA, after | pipeline, before → after | finalise, before → after |
|---|---|---|---|---|---|
| Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz | 1 | 4h37m42s | 4h35m24s | 45m21s → 44m10s | 2h13m48s → 2h13m48s |

</details>

**The split from the gz dump** (`WIKIDATA_DUMP_FORMAT=gz`, decoded by igzip) against the split from the bz2, run after the timed run and outside its figures. The ETA is the split's CPU time per byte of the slice's dump, scaled to the newest dump on record (103.5 GB bz2, 156.6 GB gz) over the cores; decoding alone is the decoder by itself on the slice, its wall time scaled the same way (lbzip2 decodes on every core, gz decoders on one), a floor under the split's wall time that the ETA does not take in.

| | before, bz2 | before, gz | after, bz2 | after, gz |
|---|---|---|---|---|
| ETA: split | 1h38m33s | 1h25m20s | 1h37m27s | 1h25m53s |
| decoding alone, wall | 53m08s | 9m36s | 52m55s | 9m22s |
| the slice (MB) | 79.2 | 117.0 | 79.2 | 117.0 |
| CPU, split, the slice | 18.1s | 15.3s | 17.9s | 15.4s |
| CPU, decoding alone, the slice | 48.3s | 0.4s | 48.1s | 0.4s |
| wall, split, the slice | 4.64s | 4.85s | 4.64s | 4.83s |
| peak RSS, split (MB) | 3420 | 3580 | 3411 | 3521 |
| parity, split | passed | passed | passed | passed |

The split's parity: its chunks hold exactly the sample's rows; from gz, its manifests are also those of the split from bz2.

**The split and both sets' pipelines as a release runs them, the emulated link, and the release wall modelled from them:** not run on this PR (full tier on master)

**Parity:** passed

**Parity, the misfit chunk:** not run on this PR (full tier on master)

**Parity, a new claims field:** not run on this PR (full tier on master)

**The split's census of the slice's order** (after): 33,219 Q ids in 4 shards; past the shards' heads at most 1,006 below their running maximum, 0 more than 10,000 below; in the heads (below Q10,000) at most 1,968, 0 more than 10,000 below; its CPU time 0.02s in the split's workers, 0.10% of the split's

**The split by the native bz2 decoder** (after, 9 decoding threads; `WIKIDATA_BZ2_DECODER=native`, against lbzip2's, both untimed, on each runner): CPU 17.8s against 66.6s (-73.3% ±0.0%), wall 4.64s against 6.28s (-26.1% ±0.0%), peak RSS 3393 MB against 3600 MB (-5.8% ±0.0%); the decoders alone on the slice, CPU 4.6s against 48.2s (-90.5% ±0.0%), wall 1.00s against 2.62s (-61.8% ±0.0%). **Parity, every file both splits wrote byte for byte:** passed (68 files)

**Checks:** the PR tier: the timed core and parity, then the split from the gz dump and on bench 10.0.0's orjson slice (pipeline.py --split-gz): ran (changes `reshape/Cargo.lock`, `reshape/Cargo.toml`); the stages overlapped and over the emulated link (overlap.py, link.py), and the release wall modelled from them: not run on this PR (full tier on master); the misfit chunk (misfit.py): not run on this PR (full tier on master); a new claims field (evolve.py): not run on this PR (full tier on master); the native bz2 decoder against lbzip2 (bz2native.py): ran (the PR tier; mibz2 0.3.1 (43ee26e9749a) → 0.3.3 (6054a1b32d90) in reshape/Cargo.lock; changes `reshape/Cargo.toml`).

**before:** measured in this run

| | before (`cd305f33c`) | after (`a3047bfec`) | change |
|---|---|---|---|
| measured, end to end: CPU (split + pipeline + finalise) | 4m04s | 3m54s | **-10.5s (-4.3% ±0.0%)** |
| measured, end to end: wall (split + pipeline + finalise) | 1m09s | 1m08s | **-0.79s (-1.1% ±0.0%)** |
| ETA, a release | 4h37m42s | 4h35m24s | **-2m18s (-0.8% ±0.0%)** |
| ETA: pipeline | 45m21s | 44m10s | **-1m11s (-2.6% ±0.0%)** |
| ETA: finalise | 2h13m48s | = |  |
| ETA: split | 1h38m33s | 1h37m27s | **-1m06s (-1.1% ±0.0%)** |
| measured, end to end, with the claims refs: CPU | 4m05s | 3m54s | **-10.5s (-4.3% ±0.0%)** |
| measured, end to end, with the claims refs: wall | 1m09s | 1m08s | **-0.79s (-1.1% ±0.0%)** |
| ETA, a release, with the claims refs | 4h38m32s | 4h36m14s | **-2m18s (-0.8% ±0.0%)** |
| ETA: claims refs, modelled | 50s | = |  |
| release wall, modelled: stages overlapped, uploads at 7 MB/s, finalise and claims refs | not run on this PR (full tier on master) | | |
| dump on disk to output on disk, modelled: stages overlapped, no transfers | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 7 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 30 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 60 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers: link at 120 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 7 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 30 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 60 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled, with finalise's transfers and the upload calls' costs: link at 120 MB/s | not run on this PR (full tier on master) | | |
| release wall, modelled as bench 17.1.0 did | not run on this PR (full tier on master) | | |
| claims refs | 0.09s | = |  |
| CPU, claims refs | 0.5s | = |  |
| claims refs, 3× the rows | 0.14s | = |  |
| CPU, claims refs, 3× the rows | 0.8s | = |  |
| peak RSS, claims refs: all processes (MB) | 434 | 446 | **+12 (+2.8% ±0.0%)** |
| peak RSS, claims refs: one worker (MB) | 21 | = |  |
| peak RSS, claims refs 3×: all processes (MB) | 567 | 481 | **-86 (-15.2% ±0.0%)** |
| peak RSS, claims refs 3×: one worker (MB) | 21 | = |  |
| claims_labels: build, compact, sort | 2.07s | 2.03s | **-0.04s (-1.9% ±0.0%)** |
| CPU, claims_labels | 11.3s | 11.2s | **-0.1s (-0.9% ±0.0%)** |
| claims_labels, 3× the rows | 2.45s | 2.44s | **-0.01s (-0.4% ±0.0%)** |
| CPU, claims_labels, 3× the rows | 18.5s | = |  |
| peak RSS, claims_labels: all processes (GB) | 1.541 | 1.401 | **-0.140 (-9.1% ±0.0%)** |
| peak RSS, claims_labels: one worker (MB) | 332 | 297 | **-35 (-10.5% ±0.0%)** |
| peak RSS, claims_labels 3×: all processes (GB) | 1.605 | 1.630 | **+0.025 (+1.6% ±0.0%)** |
| peak RSS, claims_labels 3×: one worker (MB) | 342 | 344 | **+2 (+0.6% ±0.0%)** |
| measured, split then each set's pipeline: wall | not run on this PR (full tier on master) | | |
| measured, split and both sets' pipelines at once: wall | not run on this PR (full tier on master) | | |
| peak RSS, split then each set's pipeline: every process | not run on this PR (full tier on master) | | |
| peak RSS, split and both sets' pipelines at once: every process | not run on this PR (full tier on master) | | |
| uploads at a release, modelled at 7 MB/s | not run on this PR (full tier on master) | | |
| measured, split and both sets' pipelines at once, pushes over a 7 MB/s link: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs through the stand-in Hub, no link: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 7 MB/s link: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 60 MB/s link: wall | not run on this PR (full tier on master) | | |
| measured, both sets' pipelines at once, pushes over a 7 MB/s link with the calls' costs: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 7 MB/s link with the calls' costs: wall | not run on this PR (full tier on master) | | |
| measured, finalise's three runs over a 60 MB/s link with the calls' costs: wall | not run on this PR (full tier on master) | | |
| measured, a misfit chunk (c0 with a reference's coordinate): CPU, split and process | not run on this PR (full tier on master) | | |
| measured, a misfit chunk: wall, split and process | not run on this PR (full tier on master) | | |
| measured, a misfit chunk: CPU, split | not run on this PR (full tier on master) | | |
| measured, a misfit chunk: CPU, process | not run on this PR (full tier on master) | | |
| measured, a new claims field (c0, a mainsnak's): CPU, the process step finding it | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, the process step once it is known (JSON) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, the split, the field known (built) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, the split, the field not known (JSON) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, a version 0 claims file written in version 1 (a merge) | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, a version 0 claims file read | not run on this PR (full tier on master) | | |
| measured, a new claims field: CPU, a version 0 claims file read as version 1 (finalise) | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: the process step finding it | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: a version 0 claims file written in version 1 | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: a version 0 claims file read | not run on this PR (full tier on master) | | |
| peak RSS, a new claims field: a version 0 claims file read as version 1 | not run on this PR (full tier on master) | | |
| disk, a new claims field: a version 0 claims file written in version 1 (MB, until merged) | not run on this PR (full tier on master) | | |
| wall, with finalise | 1m04s | = |  |
| wall | 2.74s | 2.77s | **+0.03s (+1.1% ±0.0%)** |
| finalise: compact | 0.97s | 0.94s | **-0.03s (-3.1% ±0.0%)** |
| finalise: sort | 1m01s | 1m00s | **-0.79s (-1.3% ±0.0%)** |
| finalise, 3× the rows | 1m09s | 1m08s | **-0.85s (-1.2% ±0.0%)** |
| split: split | 3.84s | 3.83s | **-0.01s (-0.3% ±0.0%)** |
| split: route | 0.80s | 0.81s | **+0.01s (+1.2% ±0.0%)** |
| CPU, split | 18.1s | 17.9s | **-0.2s (-1.1% ±0.0%)** |
| peak RSS, split (GB) | 3.420 | 3.411 | **-0.009 (-0.3% ±0.0%)** |
| ETA: split from gz | 1h25m20s | 1h25m53s | **+33s (+0.6% ±0.0%)** |
| CPU, split from gz | 15.3s | 15.4s | **+0.1s (+0.7% ±0.0%)** |
| throughput (entities/s) | 12,124 | 11,993 | **-131 (-1.1% ±0.0%)** |
| CPU, all processes | 9.1s | 9.6s | **+0.5s (+5.5% ±0.0%)** |
| CPU, process | 0.1s | = |  |
| CPU, partition | 0.1s | = |  |
| CPU, group merges | 1.5s | = |  |
| CPU, finalise | 3m37s | 3m26s | **-10.8s (-5.0% ±0.0%)** |
| peak RSS, all processes (MB) | 987 | 973 | **-14 (-1.4% ±0.0%)** |
| peak RSS, one worker (MB) | 183 | = |  |
| peak RSS, finalise: all processes (GB) | 4.265 | 4.256 | **-0.009 (-0.2% ±0.0%)** |
| peak RSS, finalise: one worker (GB) | 2.015 | 2.041 | **+0.026 (+1.3% ±0.0%)** |
| peak RSS, finalise 3×: all processes (GB) | 10.753 | 10.763 | **+0.010 (+0.1% ±0.0%)** |
| peak RSS, finalise 3×: one worker (GB) | 3.136 | 3.116 | **-0.020 (-0.6% ±0.0%)** |
| peak RSS, finalise at a release, modelled: a bucket sort (GB) | 4.228 | 4.167 | **-0.061 (-1.4% ±0.0%)** |
| peak RSS, finalise at a release, modelled: all processes (GB) | 25.627 | 25.249 | **-0.378 (-1.5% ±0.0%)** |
| CPU, a claims worker outside its jobs | 1.75s | 1.73s | **-0.02s (-1.4% ±0.0%)** |
| CPU, the pipeline's claims stages | 0.0s | = |  |
| CPU, a pipeline worker outside its chunks | 1.75s | 1.87s | **+0.12s (+6.9% ±0.0%)** |
| disk used, peak rise (MB) | 841 | 580 | **-261 (-31.0% ±0.0%)** |

**Where the CPU goes**, by stage: each stage's own CPU time in its process (its worker's native threads included, the stages it calls apart), the mean over the rounds, and its share of the span's.

| stage | before | after | change |
|---|---|---|---|
| *the split and routing of the dump slice*: 4.5s → 4.5s | | | |
| `partitioning.core.write_table` | 5.9s (131%) | 6.0s (132%) | **+0.9% ±0.0%** |
| `dump.write_chunk` | 3.2s (71%) | 3.2s (70%) | **-1.9% ±0.0%** |
| `partitioning.claims.statements` | 0.1s (3%) | 0.1s (2%) | **-28.8% ±0.0%** |
| `claims_refs.write_refs` | 0.1s (2%) | 0.1s (2%) | **+3.3% ±0.0%** |
| *the pipeline, every chunk*: 1.2s → 1.2s | | | |
| `push.core.merge_group` | 1.1s (94%) | 1.1s (94%) | **+0.9% ±0.0%** |
| `process.check_ids` | 0.0s (3%) | 0.0s (3%) | **-7.3% ±0.0%** |
| `partitioning.core.write_sidecar` | 0.0s (1%) | 0.0s (1%) | **+0.0% ±0.0%** |
| `other` | 0.0s (2%) | 0.0s (2%) |  |
| *finalise, per byte (the run on three times the rows less the first; what the ETA scales)*: 44.0s → 43.8s | | | |
| `compact._write_file_parallel` | 17.7s (40%) | 17.6s (40%) | **-0.6% ±0.0%** |
| `sort_by_id._read_bucket` | 7.4s (17%) | 7.4s (17%) | **-0.7% ±0.0%** |
| `sort_by_id._check_written` | 4.7s (11%) | 4.5s (10%) | **-4.7% ±0.0%** |
| `sort_by_id._bucket_source` | 3.3s (7%) | 3.6s (8%) | **+9.1% ±0.0%** |
| `sort_by_id._sorted` | 3.5s (8%) | 3.5s (8%) | **-0.6% ±0.0%** |
| `sort_by_id._read_streams` | 2.3s (5%) | 2.3s (5%) | **-0.2% ±0.0%** |
| `compact.rewrite_table` | 1.6s (4%) | 1.6s (4%) | **-4.8% ±0.0%** |
| `sort_by_id._read_key` | 1.0s (2%) | 1.0s (2%) | **-0.9% ±0.0%** |
| `sort_by_id._ipc_stream` | 0.7s (2%) | 0.7s (2%) | **+0.4% ±0.0%** |
| `sort_by_id.check_compacted_copy` | 0.7s (2%) | 0.7s (1%) | **-3.3% ±0.0%** |
| `other` | 1.1s (2%) | 1.1s (2%) |  |

**Where finalise's wall time goes**, beside its CPU (timeline.py): each stage's wall time, the cores busy over it (the machine's CPU time over its wall, of 20) and the core-seconds left idle (20 × its wall less that CPU time), the mean over the rounds.

| stage | before | after |
|---|---|---|
| *finalise, 3× the rows* | 1m09s, 4.0 busy, 1105 idle | 1m08s, 3.8 busy, 1108 idle |
| `write_table claims: claims/all bucketing` | 2.19s, 4.8 busy, 33 idle | 2.21s, 4.9 busy, 34 idle |
| `write_table claims: claims/all bucket sorts` | 6.80s, 7.7 busy, 84 idle | 6.65s, 7.7 busy, 82 idle |
| `write_table labels` | 6.72s, 3.4 busy, 111 idle | 6.68s, 3.4 busy, 111 idle |
| `write_table descriptions` | 38.86s, 4.0 busy, 621 idle | 38.32s, 3.6 busy, 628 idle |
| `write_table aliases` | 1.71s, 2.9 busy, 29 idle | 1.71s, 2.9 busy, 29 idle |
| `write_table links` | 5.58s, 3.1 busy, 94 idle | 5.57s, 3.2 busy, 94 idle |
| *per byte: 3× the rows less the first run* | +7.58s, CPU +59s, idle +92s | +7.56s, CPU +52s, idle +99s |
| `write_table claims: claims/all bucket sorts` | +2.46s, CPU +37s, idle +12s | +2.35s, CPU +37s, idle +10s |
| `compact_table entities` | +1.08s, CPU +3s, idle +19s | +1.07s, CPU +3s, idle +19s |
| `write_table claims: claims/all bucketing` | +0.70s, CPU +7s, idle +7s | +0.76s, CPU +8s, idle +8s |
| `write_table descriptions` | +0.45s, CPU +8s, idle +1s | +0.55s, CPU +1s, idle +10s |
| `compact_table links` | +0.54s, CPU +0s, idle +10s | +0.52s, CPU +0s, idle +10s |
| `compact_table labels` | +0.35s, CPU +0s, idle +6s | +0.33s, CPU +0s, idle +6s |
| `write_table links` | +0.31s, CPU +1s, idle +5s | +0.31s, CPU +1s, idle +5s |
| `write_table labels` | +0.26s, CPU +1s, idle +5s | +0.30s, CPU +1s, idle +5s |
| `compact_table descriptions` | +0.28s, CPU +0s, idle +5s | +0.27s, CPU +0s, idle +5s |
| `compact_table aliases` | +0.28s, CPU +0s, idle +5s | +0.26s, CPU +0s, idle +5s |
| `compact_table claims` | +0.23s, CPU +0s, idle +4s | +0.23s, CPU +0s, idle +4s |
| `write_table aliases` | +0.12s, CPU +0s, idle +2s | +0.16s, CPU +0s, idle +3s |
| `check_compacted_copy links` | +0.08s, CPU +0s, idle +1s | +0.08s, CPU +0s, idle +1s |
| `check_compacted_copy labels` | +0.08s, CPU +0s, idle +2s | +0.07s, CPU -0s, idle +1s |
| `write_table entities: entities/all bucket sorts` | +0.09s, CPU -0s, idle +2s | +0.06s, CPU +0s, idle +1s |

<details><summary>Each stage's jobs, on three times the rows (after)</summary>

| stage | start → end | jobs (workers) | running at once: mean, peak | longest | last alone | cores waiting on I/O | disk busy |
|---|---|---|---|---|---|---|---|
| `compact_table claims` | 0.0s → 0.3s | – | –, – | – | – | 0.00 | 0% |
| `compact_table labels` | 0.3s → 0.9s | – | –, – | – | – | 0.00 | 0% |
| `compact_table descriptions` | 0.9s → 1.3s | – | –, – | – | – | 0.03 | 0% |
| `compact_table aliases` | 1.3s → 1.7s | – | –, – | – | – | 0.02 | 0% |
| `compact_table links` | 1.7s → 2.5s | – | –, – | – | – | 0.01 | 0% |
| `compact_table entities` | 2.5s → 3.6s | 1 (1) | 1.0, 1 | 0.0s | 0.0s | 0.00 | 0% |
| `check_compacted_copy claims` | 3.7s → 3.8s | – | –, – | – | – | 0.00 | 0% |
| `write_table claims: claims/all bucketing` | 3.8s → 6.0s | 3 (3) | 2.9, 3 | 0.8s | 0.0s | 0.00 | 0% |
| `write_table claims: claims/all bucket sorts` | 6.0s → 12.7s | 4 (4) | 3.7, 4 | 5.2s | 0.4s | 0.00 | 0% |
| `check_compacted_copy labels` | 12.7s → 12.8s | – | –, – | – | – | 0.02 | 0% |
| `write_table labels` | 12.8s → 19.5s | 564 (11) | 0.3, 4 | 0.1s | 0.0s | 0.00 | 0% |
| `write_table descriptions` | 19.6s → 57.9s | 442 (66) | 0.1, 4 | 0.1s | 0.0s | 0.00 | 0% |
| `write_table aliases` | 58.1s → 59.8s | 489 (6) | 2.1, 4 | 0.0s | 0.0s | 0.01 | 0% |
| `check_compacted_copy links` | 59.8s → 60.0s | – | –, – | – | – | 0.06 | 0% |
| `write_table links` | 60.0s → 65.5s | 827 (11) | 0.5, 4 | 0.0s | 0.0s | 0.01 | 0% |
| `replace_local_copy links` | 65.5s → 65.6s | – | –, – | – | – | 0.00 | 0% |
| `write_table entities: entities/all bucketing` | 65.6s → 66.9s | 1 (1) | 1.0, 1 | 0.0s | 0.0s | 0.00 | 0% |
| `write_table entities: entities/all bucket sorts` | 66.9s → 68.2s | 1 (1) | 1.0, 1 | 0.1s | 0.1s | 0.01 | 0% |

</details>

One round.

**Runners:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz; 20 cores, 125.7 GB, Python 3.13.7  
**Packages, before:** polars 2.0.0, polars-genson 1.6.0, pq-glue 0.3.0, pyarrow 25.0.1, orjson 3.12.0  
**Packages, after:** =  
**Data:** the 11 chunk files, SHA256SUMS hashing to `ae83fc382e62853f`  
**Harness:** bench 17.19.0


<details><summary>Section durations</summary>

Each section's wall, a mean over the 1 jobs (each a round's forward or reverse runner); a job's is both arms' together, the slowest job's in brackets. The PR tier runs on every pull request; the full tier's sections on master, nightly, and on a pull request they are relevant to (tiers.py).

| section | tier | before | after | a job |
|---|---|---|---|---|
| setup: checkouts, data, decoders, environments | PR | | | – |
| the timed core: split, pipeline, finalise, finalise 3×, claims_labels, claims refs | PR | 3m16s | 2m41s | 5m57s (5m57s) |
| parity: both arms' outputs fingerprinted and compared | PR | | | 37.0s (37.0s) |
| the split from the gz dump and on bench 10.0.0's orjson slice (pipeline.py --split-gz) | full | 39.9s | 40.2s | 1m20s (1m20s) |
| the stages overlapped and over the emulated link (overlap.py, link.py), and the release wall modelled from them | full | not run on this PR (full tier on master) | | |
| the misfit chunk (misfit.py) | full | not run on this PR (full tier on master) | | |
| a new claims field (evolve.py) | full | not run on this PR (full tier on master) | | |
| the native bz2 decoder against lbzip2 (bz2native.py) | PR | 16.7s | 16.5s | 33.2s (33.2s) |
| **the PR tier: a job's start to its figures** | | | | **–** |
| a job's start to its last section | | | | – |

</details>
<details><summary>Parity, after against before</summary>

```json
{
 "keys": 2324,
 "keys_per_table": {
  "aliases": 489,
  "claims": 1,
  "descriptions": 442,
  "entities": 1,
  "labels": 564,
  "links": 827
 },
 "keys_differing": [],
 "published_keys": 2842,
 "published_differing": [],
 "keys_reordered": [],
 "quarantine_files": 0,
 "quarantine_same": true,
 "sidecars": 35,
 "sidecars_same_set": true,
 "sidecar_columns_differing": {},
 "ok": true
}
```
</details>
