# The native bz2 decoder's threads through the split (26916b867d)

- **Machine:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz; 20 logical CPUs on 10 physical cores (L3 20480K); 125.7 GB. `auto` is 4 decoder threads here.
- **Held constant (each run's log):** [18] parse workers, [18] writer threads; every split from nothing.
- **Workload:** bench-full's run (`--release 20261019 --windows 24 --window-mb 25`); 8 rounds, each arm once a round, the order rotated and reversed (`arm_order`).
- **Paired:** each round's ratio to `auto` in the same round, the mean and its 95% interval; *lower* or *higher* only when the interval excludes no change.

## Release-shaped (bench-full run)

`run.py run --release 20261019 --windows 24 --window-mb 25`

| threads | wall (s), median | CPU-s | peak RSS (MB) | split wall (s) | split CPU-s | wall vs auto | CPU vs auto | split wall vs auto | split CPU vs auto | runs |
|---|---|---|---|---|---|---|---|---|---|---|
| auto (4) | 89 | 579 | 20790 | 19 | 210 | control | control | control | control | 8 |
| 6 (6) | 89 | 612 | 20940 | 20 | 243 | -0.0% ±0.5% (within noise) | +6.0% ±0.5% (higher) | +4.0% ±0.9% (higher) | +15.1% ±0.6% (higher) | 8 |
| 8 (8) | 90 | 632 | 20954 | 20 | 262 | +1.0% ±0.7% (higher) | +9.4% ±0.5% (higher) | +7.0% ±0.7% (higher) | +24.3% ±0.6% (higher) | 8 |
| 9 (9) | 90 | 639 | 20925 | 20 | 267 | +1.2% ±0.6% (higher) | +10.4% ±0.5% (higher) | +7.8% ±1.0% (higher) | +26.8% ±0.7% (higher) | 8 |

- **6 against auto, paired:** peak RSS +0.4% ±0.8% (within noise); +34.7 CPU-s and +0.04 s of wall saved a round, mean: 816.5 CPU-s per wall-s saved
- **8 against auto, paired:** peak RSS +0.3% ±0.9% (within noise); +54.4 CPU-s and -0.91 s of wall saved a round, mean: no wall saved
- **9 against auto, paired:** peak RSS +0.4% ±1.0% (within noise); +60.3 CPU-s and -1.05 s of wall saved a round, mean: no wall saved
- **Parity:** 32 of 32 runs ok, their published files' digest the first run's.

## The plan each arm gets (derived, not logged)

mibz2 0.3.4's Plan::for_threads, derived for 10 physical cores and a 20 MiB L3 (not logged by the split)
- `auto` (4 threads): Workers(4)
- `6` (6 threads): Workers(6)
- `8` (8 threads): Workers(8)
- `9` (9 threads): Workers(9)
