# Compute benchmark: 20261116-235404-windows24x25m-local-overlap

- **Result:** ok; both sets finalised: {'main': True, 'scholar': True}
- **Dump:** release 20261019, windows24x25m: 0.60 GB of bz2, 11.19 GB of JSON; the whole dump's md5 cfec3f8ab5fd8f6f0b70f58c590a02da, sha1 a05b8b809ab80576da6d838c67138ddf401055e6
- **Source:** local (no network on the timed path); orchestration: overlap; cards: False
- **Machine:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz, 20 CPUs, 134.96 GB RAM, ecryptfs on /home/louis/.Private (model unknown), Linux Mint 22, kernel 6.8.0-57-generic
- **Code:** ffe54484 (ffe54484f47c45f9689448734c04d0385aae4d8b), wikidata 0.1.0, wikidata-reshape 0.1.0, polars 2.0.0, pyarrow 25.0.1, pq-glue 0.3.0, polars-genson 1.6.0, orjson 3.12.0, numpy 2.5.3, huggingface-hub 1.32.0, hf-xet 1.6.0
- **Decoder:** native (lbzip2's command: ['/usr/bin/lbzip2', '-dc']; an in-process decoder's threads: 4); WIKIDATA_BZ2_DECODER=native, WIKIDATA_BZ2_THREADS=None, WIKIDATA_SPLIT_WRITER_THREADS=0

## Measured

- **Wall, end to end:** 87 s; **CPU:** 576 s (6.61 cores on average)
- **Time to the first processed chunk** (the split's first chunk written): 2.0 s; each set's first part ready for its run: {'main': 2.0, 'scholar': 2.0} s (±1 s, the monitor's interval)
- **Peak RSS, every process at once:** 20197 MB (the largest process 11017 MB); the machine's memory in use at its peak 28568 MB (least available 106394 MB, other work included)
- **Disk:** peak 1.33 GB taken (free space's fall), work tree peak 1.57 GB; the device read – GB and wrote – GB; the stages' own I/O read 0.00 GB and wrote 2.97 GB
- **Network:** received 0.00 GB, sent 0.00 GB (the machine's, every process)
- **Other work on the machine:** 2.8 CPU s besides the run's own (0.03 cores on average; mean load 10.14). Near 0, the run had the machine to itself

| stage | start s | wall s | CPU s | cores | other CPU s | peak RSS MB (tree) | read GB | written GB | machine: user / sys / iowait / idle | bound |
|---|--:|--:|--:|--:|--:|--:|--:|--:|---|---|
| split | 0 | 18.5 | 208.0 | 11.24 | 43.5 | 6955 | 0.00 | 1.01 | 62% / 5% / 0% / 34% | CPU on 11.2 of 20 cores (serial parts, or waiting on another stage) |
| run_scholar | 0 | 25.5 | 24.3 | 0.95 | 242.6 | 644 | 0.00 | 0.36 | 47% / 4% / 0% / 48% | CPU on 1.0 of 20 cores (serial parts, or waiting on another stage) |
| run_main | 0 | 24.2 | 30.7 | 1.27 | 234.6 | 657 | 0.00 | 0.50 | 49% / 4% / 0% / 47% | CPU on 1.3 of 20 cores (serial parts, or waiting on another stage) |
| finalise | 24 | 54.0 | 297.3 | 5.50 | 4.9 | 20197 | 0.00 | 1.10 | 25% / 3% / 0% / 72% | CPU on 5.5 of 20 cores (serial parts, or waiting on another stage) |
| tail_run_scholar | 78 | 1.2 | 2.6 | 2.17 | 1.5 | 103 | 0.00 | 0.00 | 9% / 1% / 0% / 90% | CPU on 2.2 of 20 cores (serial parts, or waiting on another stage) |
| tail_run_main | 80 | 1.2 | 2.6 | 2.20 | 2.9 | 88 | 0.00 | 0.00 | 14% / 1% / 0% / 85% | CPU on 2.2 of 20 cores (serial parts, or waiting on another stage) |
| tail_finalise | 81 | 6.4 | 10.5 | 1.65 | 2.5 | 352 | 0.00 | 0.00 | 9% / 0% / 0% / 91% | CPU on 1.6 of 20 cores (serial parts, or waiting on another stage) |

(Overlapped stages share the machine: their machine-wide split is the window's, not theirs alone.)

| finalise run | start s | wall s | CPU s | largest process MB |
|---|--:|--:|--:|--:|
| finalise_run1_main | 25 | 24.5 | 98.0 | 12140 |
| finalise_run2_scholar | 50 | 23.6 | 174.0 | 3421 |
| finalise_run3_main | 74 | 3.8 | 22.7 | 452 |
| tail_finalise_run1_main | 82 | 1.2 | 2.6 | 172 |
| tail_finalise_run2_scholar | 84 | 1.2 | 2.6 | 170 |
| tail_finalise_run3_main | 86 | 1.2 | 2.7 | 172 |

**claims_labels** (its build, compaction and sort, within finalise's runs): main 2.2 s wall, 18.6 s CPU; scholar 0.9 s wall, 12.5 s CPU

<details><summary>finalise's steps and the group closes (wall, CPU incl. workers)</summary>

| step | calls | wall s | CPU s |
|---|--:|--:|--:|
| main/build_claims_labels | 3 | 2.2 | 18.5 |
| main/close_group | 1 | 5.7 | 7.6 |
| main/collect_refs_stage | 4 | 0.2 | 1.2 |
| main/compact_table/aliases | 4 | 0.3 | 0.5 |
| main/compact_table/claims | 4 | 0.5 | 0.5 |
| main/compact_table/claims_labels | 3 | 0.0 | 0.0 |
| main/compact_table/descriptions | 4 | 0.4 | 0.5 |
| main/compact_table/entities | 4 | 0.1 | 0.1 |
| main/compact_table/labels | 4 | 0.4 | 0.7 |
| main/compact_table/links | 4 | 0.5 | 0.6 |
| main/sort_table/aliases | 4 | 0.3 | 1.8 |
| main/sort_table/claims | 4 | 16.1 | 62.8 |
| main/sort_table/claims_labels | 3 | 0.0 | 0.1 |
| main/sort_table/descriptions | 4 | 1.1 | 7.3 |
| main/sort_table/entities | 4 | 0.4 | 0.7 |
| main/sort_table/labels | 4 | 2.1 | 15.2 |
| main/sort_table/links | 4 | 0.3 | 1.8 |
| scholar/build_claims_labels | 2 | 0.9 | 12.4 |
| scholar/close_group | 1 | 5.4 | 3.1 |
| scholar/collect_refs_stage | 2 | 0.4 | 3.3 |
| scholar/compact_table/aliases | 2 | 0.1 | 0.1 |
| scholar/compact_table/claims | 2 | 0.4 | 0.5 |
| scholar/compact_table/claims_labels | 2 | 0.0 | 0.0 |
| scholar/compact_table/descriptions | 2 | 0.1 | 0.2 |
| scholar/compact_table/entities | 2 | 0.0 | 0.0 |
| scholar/compact_table/labels | 2 | 0.1 | 0.2 |
| scholar/compact_table/links | 2 | 0.0 | 0.1 |
| scholar/sort_table/aliases | 2 | 0.0 | 0.1 |
| scholar/sort_table/claims | 2 | 16.8 | 134.8 |
| scholar/sort_table/claims_labels | 2 | 0.0 | 0.0 |
| scholar/sort_table/descriptions | 2 | 1.0 | 6.6 |
| scholar/sort_table/entities | 2 | 0.2 | 0.2 |
| scholar/sort_table/labels | 2 | 1.7 | 11.3 |
| scholar/sort_table/links | 2 | 0.0 | 0.1 |

</details>

## Transfers a release would make (logged by the stand-in Hub, not timed)

| way | set/kind | calls | files | GB |
|---|---|--:|--:|--:|
| upload | main/commit | 14 | 2453 | 0.42 |
| upload | main/file | 6 | 6 | 0.00 |
| upload | main/group | 6 | 1982 | 0.45 |
| upload | scholar/commit | 7 | 542 | 0.33 |
| upload | scholar/file | 6 | 6 | 0.00 |
| upload | scholar/group | 6 | 305 | 0.34 |
| download | main/snapshot | 6 | 1982 | 0.45 |
| download | scholar/snapshot | 6 | 305 | 0.34 |

Uploads in all: 1.53 GB (at 7 MB/s, the one rate on record: 0.1 h; at 60 MB/s: 0.0 h; modelled, not measured).
The stand-in's own cost on the timed path (the Hub-side sha256 it computes): 2.5 s CPU over 1.53 GB.
Linked files changed after placing: 0 of 2995 checked (0 copied, not linked). Published digest: 3ad0c4aad5deeb7c6450d506038d34a1daace866f4c54d4e68ce65b4a75e3d48

## Per GB of bz2, against the CI bench's model

0.5988 GB of bz2; JSON 18.68x its bz2 bytes (the CI bench's slice 13.69x, #194's 12 windows of the real dump 17.46x).

| stage | CPU s / GB | CPU / 4 cores, s / GB (measured) | model s / GB (CI bench) | measured / model | wall s / GB | measured / model, a JSON byte |
|---|--:|--:|--:|--:|--:|--:|
| split | 347.4 | 86.8 | 116.0 | 0.75 | 30.9 | 0.55 |
| pipeline | 91.9 | 23.0 | 55.1 | 0.42 | – | 0.31 |
| finalise | 514.1 | 128.5 | 77.1 | 1.67 | – | 1.22 |

The model: bench 17.12.0's release model at master 8f7720b (6 runs, AMD EPYC 7763, 4 cores): a stage's sample CPU time scaled to the release and spread over 4 cores. Its figures are modelled; this run's are measured. A JSON byte's: the model's CPU over its slice's JSON (13.69x its bz2 bytes).

**Modelled** (this run's rates, linear in bz2 bytes, to the release's 103.5 GB): wall 4.2 h, CPU 27.7 h, peak disk ~230 GB (2.22x the bz2). this scaled run's figures times the release's bz2 bytes over its own: linear in bytes, which a sample of the dump's mix only approximates; modelled, not measured.
