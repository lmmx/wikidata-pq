# Compute benchmark: 20261115-181050-windows24x25m-local-overlap

- **Result:** ok; both sets finalised: {'main': True, 'scholar': True}
- **Dump:** release 20261019, windows24x25m: 0.60 GB of bz2, 11.19 GB of JSON; the whole dump's md5 cfec3f8ab5fd8f6f0b70f58c590a02da, sha1 a05b8b809ab80576da6d838c67138ddf401055e6
- **Source:** local (no network on the timed path); orchestration: overlap; cards: False
- **Machine:** Intel(R) Core(TM) i9-10900K CPU @ 3.70GHz, 20 CPUs, 134.96 GB RAM, ecryptfs on /home/louis/.Private (model unknown), Linux Mint 22, kernel 6.8.0-57-generic
- **Code:** 26916b86 (26916b867d8afc4b359286c0e90f2d82f7f1161b), wikidata 0.1.0, wikidata-reshape 0.1.0, polars 2.0.0, pyarrow 25.0.1, pq-glue 0.3.0, polars-genson 1.6.0, orjson 3.12.0, numpy 2.5.3, huggingface-hub 1.32.0, hf-xet 1.6.0
- **Decoder:** native (lbzip2's command: ['/usr/bin/lbzip2', '-dc']; an in-process decoder's threads: 4); WIKIDATA_BZ2_DECODER=native, WIKIDATA_BZ2_THREADS=None, WIKIDATA_SPLIT_WRITER_THREADS=0

## Measured

- **Wall, end to end:** 89 s; **CPU:** 581 s (6.51 cores on average)
- **Time to the first processed chunk** (the split's first chunk written): 2.0 s; each set's first part ready for its run: {'main': 2.0, 'scholar': 2.0} s (±1 s, the monitor's interval)
- **Peak RSS, every process at once:** 20992 MB (the largest process 10921 MB); the machine's memory in use at its peak 28636 MB (least available 106325 MB, other work included)
- **Disk:** peak 1.27 GB taken (free space's fall), work tree peak 1.75 GB; the device read – GB and wrote – GB; the stages' own I/O read 0.00 GB and wrote 2.97 GB
- **Network:** received 0.00 GB, sent 0.00 GB (the machine's, every process)
- **Other work on the machine:** 2.2 CPU s besides the run's own (0.02 cores on average; mean load 8.5). Near 0, the run had the machine to itself

| stage | start s | wall s | CPU s | cores | other CPU s | peak RSS MB (tree) | read GB | written GB | machine: user / sys / iowait / idle | bound |
|---|--:|--:|--:|--:|--:|--:|--:|--:|---|---|
| split | 0 | 19.0 | 210.3 | 11.08 | 40.9 | 6636 | 0.00 | 1.01 | 62% / 5% / 0% / 34% | CPU on 11.1 of 20 cores (serial parts, or waiting on another stage) |
| run_scholar | 0 | 27.6 | 24.4 | 0.88 | 244.6 | 639 | 0.00 | 0.36 | 44% / 4% / 0% / 52% | CPU on 0.9 of 20 cores (serial parts, or waiting on another stage) |
| run_main | 0 | 26.3 | 30.7 | 1.17 | 236.6 | 654 | 0.00 | 0.50 | 46% / 4% / 0% / 50% | CPU on 1.2 of 20 cores (serial parts, or waiting on another stage) |
| finalise | 26 | 54.0 | 299.7 | 5.55 | 3.8 | 20992 | 0.00 | 1.10 | 25% / 3% / 0% / 72% | CPU on 5.5 of 20 cores (serial parts, or waiting on another stage) |
| tail_run_scholar | 80 | 1.2 | 2.6 | 2.19 | 1.7 | 92 | 0.00 | 0.00 | 10% / 1% / 0% / 89% | CPU on 2.2 of 20 cores (serial parts, or waiting on another stage) |
| tail_run_main | 82 | 1.2 | 2.7 | 2.18 | 3.7 | 87 | 0.00 | 0.00 | 15% / 0% / 0% / 84% | CPU on 2.2 of 20 cores (serial parts, or waiting on another stage) |
| tail_finalise | 83 | 6.4 | 10.5 | 1.64 | 2.5 | 320 | 0.00 | 0.00 | 8% / 0% / 0% / 91% | CPU on 1.6 of 20 cores (serial parts, or waiting on another stage) |

(Overlapped stages share the machine: their machine-wide split is the window's, not theirs alone.)

| finalise run | start s | wall s | CPU s | largest process MB |
|---|--:|--:|--:|--:|
| finalise_run1_main | 27 | 24.7 | 97.8 | 12178 |
| finalise_run2_scholar | 52 | 23.7 | 176.6 | 3443 |
| finalise_run3_main | 76 | 3.8 | 22.7 | 449 |
| tail_finalise_run1_main | 84 | 1.2 | 2.7 | 172 |
| tail_finalise_run2_scholar | 86 | 1.2 | 2.6 | 170 |
| tail_finalise_run3_main | 88 | 1.2 | 2.6 | 172 |

**claims_labels** (its build, compaction and sort, within finalise's runs): main 2.2 s wall, 18.6 s CPU; scholar 0.9 s wall, 13.0 s CPU

<details><summary>finalise's steps and the group closes (wall, CPU incl. workers)</summary>

| step | calls | wall s | CPU s |
|---|--:|--:|--:|
| main/build_claims_labels | 3 | 2.1 | 18.6 |
| main/close_group | 1 | 5.5 | 7.3 |
| main/collect_refs_stage | 4 | 0.2 | 1.2 |
| main/compact_table/aliases | 4 | 0.3 | 0.5 |
| main/compact_table/claims | 4 | 0.5 | 0.5 |
| main/compact_table/claims_labels | 3 | 0.0 | 0.0 |
| main/compact_table/descriptions | 4 | 0.3 | 0.5 |
| main/compact_table/entities | 4 | 0.1 | 0.1 |
| main/compact_table/labels | 4 | 0.4 | 0.8 |
| main/compact_table/links | 4 | 0.5 | 0.6 |
| main/sort_table/aliases | 4 | 0.3 | 1.8 |
| main/sort_table/claims | 4 | 16.2 | 62.6 |
| main/sort_table/claims_labels | 3 | 0.0 | 0.1 |
| main/sort_table/descriptions | 4 | 1.1 | 7.4 |
| main/sort_table/entities | 4 | 0.4 | 0.7 |
| main/sort_table/labels | 4 | 2.1 | 15.0 |
| main/sort_table/links | 4 | 0.3 | 1.9 |
| scholar/build_claims_labels | 2 | 0.9 | 12.9 |
| scholar/close_group | 1 | 7.2 | 3.2 |
| scholar/collect_refs_stage | 2 | 0.4 | 3.4 |
| scholar/compact_table/aliases | 2 | 0.1 | 0.1 |
| scholar/compact_table/claims | 2 | 0.4 | 0.5 |
| scholar/compact_table/claims_labels | 2 | 0.0 | 0.0 |
| scholar/compact_table/descriptions | 2 | 0.2 | 0.2 |
| scholar/compact_table/entities | 2 | 0.0 | 0.1 |
| scholar/compact_table/labels | 2 | 0.1 | 0.2 |
| scholar/compact_table/links | 2 | 0.0 | 0.1 |
| scholar/sort_table/aliases | 2 | 0.0 | 0.1 |
| scholar/sort_table/claims | 2 | 16.9 | 136.3 |
| scholar/sort_table/claims_labels | 2 | 0.0 | 0.1 |
| scholar/sort_table/descriptions | 2 | 1.1 | 6.9 |
| scholar/sort_table/entities | 2 | 0.2 | 0.2 |
| scholar/sort_table/labels | 2 | 1.7 | 11.3 |
| scholar/sort_table/links | 2 | 0.0 | 0.1 |

</details>

## Transfers a release would make (logged by the stand-in Hub, not timed)

| way | set/kind | calls | files | GB |
|---|---|--:|--:|--:|
| upload | main/commit | 14 | 2453 | 0.42 |
| upload | main/file | 6 | 6 | 0.00 |
| upload | main/group | 6 | 1982 | 0.45 |
| upload | scholar/commit | 7 | 542 | 0.33 |
| upload | scholar/file | 6 | 6 | 0.00 |
| upload | scholar/group | 6 | 305 | 0.34 |
| download | main/snapshot | 6 | 1982 | 0.45 |
| download | scholar/snapshot | 6 | 305 | 0.34 |

Uploads in all: 1.53 GB (at 7 MB/s, the one rate on record: 0.1 h; at 60 MB/s: 0.0 h; modelled, not measured).
The stand-in's own cost on the timed path (the Hub-side sha256 it computes): 2.6 s CPU over 1.53 GB.
Linked files changed after placing: 0 of 2995 checked (0 copied, not linked). Published digest: 3ad0c4aad5deeb7c6450d506038d34a1daace866f4c54d4e68ce65b4a75e3d48

## Per GB of bz2, against the CI bench's model

0.5988 GB of bz2; JSON 18.68x its bz2 bytes (the CI bench's slice 13.69x, #194's 12 windows of the real dump 17.46x).

| stage | CPU s / GB | CPU / 4 cores, s / GB (measured) | model s / GB (CI bench) | measured / model | wall s / GB | measured / model, a JSON byte |
|---|--:|--:|--:|--:|--:|--:|
| split | 351.2 | 87.8 | 116.0 | 0.76 | 31.7 | 0.55 |
| pipeline | 92.0 | 23.0 | 55.1 | 0.42 | – | 0.31 |
| finalise | 518.1 | 129.5 | 77.1 | 1.68 | – | 1.23 |

The model: bench 17.12.0's release model at master 8f7720b (6 runs, AMD EPYC 7763, 4 cores): a stage's sample CPU time scaled to the release and spread over 4 cores. Its figures are modelled; this run's are measured. A JSON byte's: the model's CPU over its slice's JSON (13.69x its bz2 bytes).

**Modelled** (this run's rates, linear in bz2 bytes, to the release's 103.5 GB): wall 4.3 h, CPU 27.9 h, peak disk ~220 GB (2.12x the bz2). this scaled run's figures times the release's bz2 bytes over its own: linear in bytes, which a sample of the dump's mix only approximates; modelled, not measured.
